"""
RAG 链实现 - 检索增强生成
"""
from typing import List, Optional
from pathlib import Path

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

from models import get_llm, get_embedding_model
from utils import load_documents, split_documents
from config.settings import settings


class RAGChain:
    """RAG 链类，封装检索和生成逻辑"""
    
    def __init__(
        self,
        vector_store_path: Optional[str] = None,
        persist: bool = True,
    ):
        """
        初始化 RAG 链
        
        Args:
            vector_store_path: 向量存储路径，默认使用配置值
            persist: 是否持久化向量存储
        """
        self.vector_store_path = vector_store_path or settings.VECTOR_STORE_PATH
        self.persist = persist
        self.llm = get_llm()
        self.embeddings = get_embedding_model()
        self.vector_store: Optional[FAISS] = None
        self.retriever = None
        self.chain = None
        
        # 创建向量存储目录
        Path(self.vector_store_path).mkdir(parents=True, exist_ok=True)
    
    def build_vector_store(self, documents: List[Document], append: bool = False) -> None:
        """
        构建向量存储
        
        Args:
            documents: 文档列表
            append: 如果为 True 且向量存储已存在，则追加文档；否则覆盖
        """
        if not documents:
            raise ValueError("文档列表不能为空")
        
        # 分割文档
        split_docs = split_documents(documents)
        
        # 检查向量存储是否已存在
        vector_store_file = Path(self.vector_store_path) / "index.faiss"
        
        if append and vector_store_file.exists():
            # 如果启用追加模式且向量存储已存在，则加载并添加文档
            print("检测到已存在的向量存储，正在加载...")
            self.vector_store = FAISS.load_local(
                self.vector_store_path,
                self.embeddings,
                allow_dangerous_deserialization=True,
            )
            print(f"正在添加 {len(split_docs)} 个文档块到现有向量存储...")
            self.vector_store.add_documents(split_docs)
        else:
            # 创建新的向量存储（覆盖已存在的）
            if vector_store_file.exists():
                print("警告: 向量存储已存在，将被覆盖。如需增量添加，请使用 append=True 参数。")
            self.vector_store = FAISS.from_documents(
                documents=split_docs,
                embedding=self.embeddings,
            )
        
        # 持久化
        if self.persist:
            self.vector_store.save_local(self.vector_store_path)
        
        # 创建检索器
        self.retriever = self.vector_store.as_retriever(
            search_kwargs={"k": settings.TOP_K}
        )
        
        # 构建 RAG 链
        self._build_chain()
    
    def load_vector_store(self) -> None:
        """
        从磁盘加载向量存储
        """
        vector_store_file = Path(self.vector_store_path) / "index.faiss"
        
        if not vector_store_file.exists():
            raise FileNotFoundError(
                f"向量存储不存在: {self.vector_store_path}。请先调用 build_vector_store() 构建向量存储。"
            )
        
        self.vector_store = FAISS.load_local(
            self.vector_store_path,
            self.embeddings,
            allow_dangerous_deserialization=True,
        )
        
        # 创建检索器
        self.retriever = self.vector_store.as_retriever(
            search_kwargs={"k": settings.TOP_K}
        )
        
        # 构建 RAG 链
        self._build_chain()
    
    def _build_chain(self) -> None:
        """构建 RAG 链"""
        # 定义提示模板
        template = """基于以下上下文信息回答问题。如果上下文中没有相关信息，请说明你不知道，不要编造答案。

上下文信息：
{context}

问题：{question}

请提供准确、有用的答案："""
        
        prompt = ChatPromptTemplate.from_template(template)
        
        # 构建链：检索 -> 格式化 -> LLM -> 输出解析
        self.chain = (
            {
                "context": self.retriever | self._format_docs,
                "question": RunnablePassthrough(),
            }
            | prompt
            | self.llm
            | StrOutputParser()
        )
    
    @staticmethod
    def _format_docs(docs: List[Document]) -> str:
        """
        格式化检索到的文档
        
        Args:
            docs: 文档列表
        
        Returns:
            格式化后的字符串
        """
        return "\n\n".join(doc.page_content for doc in docs)
    
    def query(self, question: str) -> str:
        """
        查询 RAG 系统
        
        Args:
            question: 用户问题
        
        Returns:
            生成的答案
        """
        if self.chain is None:
            raise ValueError(
                "RAG 链未初始化。请先调用 build_vector_store() 或 load_vector_store()。"
            )
        
        return self.chain.invoke(question)
    
    def add_documents(self, documents: List[Document]) -> None:
        """
        向现有向量存储添加文档
        
        Args:
            documents: 新文档列表
        """
        if self.vector_store is None:
            raise ValueError("向量存储未初始化。请先调用 build_vector_store() 或 load_vector_store()。")
        
        # 分割文档
        split_docs = split_documents(documents)
        
        # 添加文档到向量存储
        self.vector_store.add_documents(split_docs)
        
        # 重新创建检索器
        self.retriever = self.vector_store.as_retriever(
            search_kwargs={"k": settings.TOP_K}
        )
        
        # 重新构建链
        self._build_chain()
        
        # 持久化
        if self.persist:
            self.vector_store.save_local(self.vector_store_path)

