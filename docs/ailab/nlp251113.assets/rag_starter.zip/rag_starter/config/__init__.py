"""
配置模块
"""
from .settings import settings

__all__ = ["settings"]

