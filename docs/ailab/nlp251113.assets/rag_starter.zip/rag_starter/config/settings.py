"""
配置文件 - 存储模型端点和其他配置信息
"""
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """应用配置"""
    
    # LLM 模型配置
    LLM_BASE_URL: str = "http://172.18.144.18/svc/DGsanOif-1/v1"
    LLM_MODEL_NAME: str = "qwen2.5:32b"
    LLM_API_KEY: str = "EMPTY"
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 2048
    
    # 嵌入模型配置
    EMBEDDING_BASE_URL: str = "http://172.18.144.18/svc/97iYTIRw-1/v1"
    EMBEDDING_MODEL_NAME: str = "qwen3-embedding:8b"
    EMBEDDING_API_KEY: str = "EMPTY"
    EMBEDDING_DIMENSION: int = 1024  # 根据实际模型调整
    
    # 向量存储配置
    VECTOR_STORE_PATH: str = "./vectorstore"
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    
    # 检索配置
    TOP_K: int = 4  # 检索相关文档数量
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# 全局配置实例
settings = Settings()

