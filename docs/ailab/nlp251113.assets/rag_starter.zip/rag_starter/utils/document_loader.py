"""
文档加载和分割工具
"""
from pathlib import Path
from typing import List, Union

from langchain_community.document_loaders import (
    TextLoader,
    PyPDFLoader,
    UnstructuredMarkdownLoader,
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from config.settings import settings


def load_documents(file_path: Union[str, Path]) -> List[Document]:
    """
    根据文件类型加载文档
    
    Args:
        file_path: 文件路径
    
    Returns:
        文档列表
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    suffix = file_path.suffix.lower()
    
    # 根据文件类型选择加载器
    if suffix == ".txt":
        loader = TextLoader(str(file_path), encoding="utf-8")
    elif suffix == ".pdf":
        loader = PyPDFLoader(str(file_path))
    elif suffix in [".md", ".markdown"]:
        loader = UnstructuredMarkdownLoader(str(file_path))
    else:
        # 默认使用文本加载器
        loader = TextLoader(str(file_path), encoding="utf-8")
    
    documents = loader.load()
    return documents


def split_documents(documents: List[Document]) -> List[Document]:
    """
    将文档分割成小块
    
    Args:
        documents: 原始文档列表
    
    Returns:
        分割后的文档列表
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=settings.CHUNK_SIZE,
        chunk_overlap=settings.CHUNK_OVERLAP,
        length_function=len,
    )
    
    split_docs = text_splitter.split_documents(documents)
    return split_docs

