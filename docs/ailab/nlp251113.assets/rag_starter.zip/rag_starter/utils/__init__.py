"""
工具模块 - 导出文档加载器
"""
from .document_loader import load_documents, split_documents

__all__ = ["load_documents", "split_documents"]

