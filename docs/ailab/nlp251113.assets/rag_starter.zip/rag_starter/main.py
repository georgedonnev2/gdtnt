"""
RAG 系统主程序入口
"""
import argparse
from pathlib import Path

from chains import RAGChain
from utils import load_documents


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="RAG 系统 - 检索增强生成")
    parser.add_argument(
        "--mode",
        type=str,
        choices=["build", "query", "interactive"],
        default="interactive",
        help="运行模式: build(构建向量存储), query(单次查询), interactive(交互模式)",
    )
    parser.add_argument(
        "--file",
        type=str,
        help="要加载的文档文件路径（用于 build 模式）",
    )
    parser.add_argument(
        "--question",
        type=str,
        help="要查询的问题（用于 query 模式）",
    )
    parser.add_argument(
        "--vector-store",
        type=str,
        default="./vectorstore",
        help="向量存储路径",
    )
    parser.add_argument(
        "--append",
        action="store_true",
        help="增量添加模式：如果向量存储已存在，则追加文档而不是覆盖（仅用于 build 模式）",
    )
    
    args = parser.parse_args()
    
    # 初始化 RAG 链
    rag = RAGChain(vector_store_path=args.vector_store)
    
    if args.mode == "build":
        # 构建模式：加载文档并构建向量存储
        if not args.file:
            print("错误: build 模式需要指定 --file 参数")
            return
        
        print(f"正在加载文档: {args.file}")
        documents = load_documents(args.file)
        print(f"已加载 {len(documents)} 个文档")
        
        if args.append:
            print("使用增量添加模式...")
        else:
            print("正在构建向量存储...")
        rag.build_vector_store(documents, append=args.append)
        print(f"向量存储已构建并保存到: {args.vector_store}")
    
    elif args.mode == "query":
        # 查询模式：单次查询
        if not args.question:
            print("错误: query 模式需要指定 --question 参数")
            return
        
        print("正在加载向量存储...")
        try:
            rag.load_vector_store()
        except FileNotFoundError:
            print("错误: 向量存储不存在。请先使用 build 模式构建向量存储。")
            return
        
        print(f"问题: {args.question}")
        print("正在生成答案...")
        answer = rag.query(args.question)
        print(f"\n答案:\n{answer}")
    
    elif args.mode == "interactive":
        # 交互模式：持续对话
        print("正在加载向量存储...")
        try:
            rag.load_vector_store()
        except FileNotFoundError:
            print("错误: 向量存储不存在。请先使用 build 模式构建向量存储。")
            print("示例命令: python main.py --mode build --file your_document.txt")
            return
        
        print("RAG 系统已就绪！输入 'quit' 或 'exit' 退出。\n")
        
        while True:
            question = input("请输入您的问题: ").strip()
            
            if question.lower() in ["quit", "exit", "退出"]:
                print("再见！")
                break
            
            if not question:
                continue
            
            try:
                print("正在生成答案...")
                answer = rag.query(question)
                print(f"\n答案:\n{answer}\n")
            except Exception as e:
                print(f"错误: {e}\n")


if __name__ == "__main__":
    main()

