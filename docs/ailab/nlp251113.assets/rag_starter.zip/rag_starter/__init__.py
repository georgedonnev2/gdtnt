"""
RAG Starter - 基于 LangChain 的 RAG 系统
"""
__version__ = "1.0.0"

