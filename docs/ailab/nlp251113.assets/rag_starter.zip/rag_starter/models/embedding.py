"""
嵌入模型封装 - 使用 LangChain 的 OpenAIEmbeddings 兼容接口
"""
from langchain_openai import OpenAIEmbeddings
from langchain_core.embeddings import Embeddings

from config.settings import settings


def get_embedding_model() -> Embeddings:
    """
    获取嵌入模型实例
    
    Returns:
        LangChain Embeddings 实例
    """
    return OpenAIEmbeddings(
        base_url=settings.EMBEDDING_BASE_URL,
        model=settings.EMBEDDING_MODEL_NAME,
        api_key=settings.EMBEDDING_API_KEY
    )

