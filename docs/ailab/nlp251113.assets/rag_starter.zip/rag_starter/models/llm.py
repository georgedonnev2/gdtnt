"""
LLM 模型封装 - 使用 LangChain 的 ChatOpenAI 兼容接口
"""
from typing import Optional
from langchain_openai import ChatOpenAI
from langchain_core.language_models.chat_models import BaseChatModel

from config.settings import settings


def get_llm(
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
) -> BaseChatModel:
    """
    获取 LLM 模型实例
    
    Args:
        temperature: 生成温度，默认使用配置值
        max_tokens: 最大生成token数，默认使用配置值
    
    Returns:
        LangChain ChatModel 实例
    """
    return ChatOpenAI(
        base_url=settings.LLM_BASE_URL,
        model=settings.LLM_MODEL_NAME,
        temperature=temperature or settings.LLM_TEMPERATURE,
        max_tokens=max_tokens or settings.LLM_MAX_TOKENS,
        api_key=settings.LLM_API_KEY
    )

